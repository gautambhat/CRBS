<?php
	
	echo '<div style="width:100%;min-width:60em;"><div id="ABCConf">
			<span style="padding-left:23px;color:#13c5ff;">ABC</span>
		</div>
		<div id="header">	
			<ul id="menu">
                <li><a href="start.php">Home</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="rules.php">Rules</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div></div>
		';

?>