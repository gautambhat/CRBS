var preload_ctrl_images=true;


var previmg='button_rewind.png';
var stopimg='button_pause.png';
var playimg='button_play.png';
var nextimg='button_fast_forward.png';

var slideShow=[];


slideShow[0] = ["C3.jpg", "Seminar Hall 3", "_new", "top=0, left=0, width=100%, height=100%, location, resizable, scrollbars"];
slideShow[1] = ["C1.jpg", "Seminar Hall 2"];
slideShow[2] = ["C2.jpg", "Seminar Hall 1"];



slideShow.no_descriptions=0; 
slideShow.pause=1; 
slideShow.image_controls=1; 
slideShow.button_highlight= 'blue'; 
slideShow.manual_start=1; 
slideShow.delay=1500; 
slideShow.no_added_linebreaks=1; 
