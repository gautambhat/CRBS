<?php
	$configHostName = "localhost";
	$configRootName = "root";
	$configAccessPassword = "";
	$configDatabaseName = "cbs";
?>